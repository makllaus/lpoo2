package corridacavalo;

/**
 *
 * @author user
 */
public class CorridaCavalo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.util.Scanner scan = new java.util.Scanner(System.in);
        boolean done = true;
        while (done) {
            System.out.println("Simulador de Corrida de Cavalos   (versão texto 0.1)");
            System.out.println("-------------------------------------------------------\n");
            System.out.print("Quantos jogadores irão participar dessa corrida (de 1 a 10)? ");
            int numApostadores = 0;
            do {
                numApostadores = scan.nextInt();
                scan.nextLine(); // consome a quebra de linha (ENTER)
                if (numApostadores < 1 || numApostadores > 10) {
                    System.out.println("Valor de entrada inválido. Digite um número de 1 a 10.\n");
                    System.out.print("Quantos jogadores irão participar dessa corrida (de 1 a 10)? ");
                }
            } while (numApostadores < 1 || numApostadores > 10);
            //
            // lê as apostas
            String[] jogadores = new String[numApostadores];
            int[] apostas = new int[numApostadores];
            for (int i = 0; i < numApostadores; i++) {
                System.out.printf("Nome do %do jogador: ", i + 1);
                jogadores[i] = scan.nextLine();
                System.out.printf("Aposta do %do jogador (cavalo de 1 a 10): ", i + 1);
                int aposta = 0;
                do {
                    aposta = scan.nextInt();
                    scan.nextLine(); // consome a quebra de linha (ENTER)
                    if (aposta < 1 || aposta > 10) {
                        System.out.println("Valor de entrada inválido. Digite um número de 1 a 10.\n");
                        System.out.printf("Aposta do %do jogador (cavalo de 1 a 10)? ", i + 1);
                    }
                } while (aposta < 1 || aposta > 10);
                apostas[i] = aposta;
            }
            JuizMonitor juiz = new JuizMonitor();
            // cria as threads e coloca elas para executar
            juiz.preparaCorrida(10, 50, 50, 1000);
            // da a largada
            juiz.iniciaCorrida();
            // espera o fim da corrida
            juiz.aguardaCorridaEncerrar();
            // obtém os resultados
            int[] rank = juiz.vencedores();
            //
            // apresenta o resultado final
            for (int i = 0; i < rank.length; i++) {
                System.out.printf("\nO cavalo %d venceu em %do lugar\n", rank[i], i + 1);
                boolean teveApostador = false;
                for (int j = 0; j < numApostadores; j++) {
                    if (apostas[j] == rank[i]) {
                        System.out.printf("\t%s\n", jogadores[j]);
                        teveApostador = true;
                    }
                }
                if( !teveApostador ) {
                    System.out.println("\tNinguém apostou no vencedor.");
                }
            }
            //
            //
            System.out.print("Jogar novamente (S/N)? ");
            String jogarNovamente = "";
            do {
                jogarNovamente = scan.nextLine();
                if (jogarNovamente.equalsIgnoreCase("S") || jogarNovamente.equalsIgnoreCase("N")) {
                    break;
                }
                System.out.print("Jogar novamente (S/N)? ");
            } while (true);
            done = jogarNovamente.equalsIgnoreCase("S");
        }
    }
}