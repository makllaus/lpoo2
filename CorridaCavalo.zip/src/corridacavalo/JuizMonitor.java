package corridacavalo;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class JuizMonitor {
    private boolean iniciouCorrida = false;
    private int[] rank = new int[10];
    private int rankIndex = 0;
    private CavaloThread[] cavalos = new CavaloThread[10];
    
    public JuizMonitor(){
    }

    public void preparaCorrida(int minDistance, int maxDistance, int tempoLatencia, int tamPista) {
        for(int i=0 ; i<cavalos.length ; i++ ) {
            cavalos[i] = new CavaloThread(i+1,this);
            cavalos[i].configura(minDistance, maxDistance, tempoLatencia, tamPista);
            cavalos[i].start();
        }
        try {
            Thread.sleep(100);
        } catch (InterruptedException ex) {
            Logger.getLogger(JuizMonitor.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Todos prontos...");
    }

    public synchronized boolean largou() {
        return iniciouCorrida;
    }

    public void encerrou(int num) {
        synchronized(this) {
            rank[rankIndex] = num;
            rankIndex++;
        }
    }

    public synchronized void iniciaCorrida() {
        System.out.println("começou");
        this.iniciouCorrida = true;
    }

    public void aguardaCorridaEncerrar() {
        while( true ) {
            if( rankIndex >= 10 ) {
                break;
            }
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(JuizMonitor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public int[] vencedores() {
        int[] result = new int[3];
        for(int i=0 ; i<result.length ; i++) {
            result[i] = rank[i];
        }
        return result;
    }
    
}
