package corridacavalo;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Dieval Guizelini
 */
public class CavaloThread extends Thread {
    private final int num;
    private final JuizMonitor monitor;
    private int menorDistancia = 0;
    private int maiorDistancia = 10;
    private int tempoEspera = 100;
    private int distanciaPercurso = 1000;
    
    public CavaloThread(int num, JuizMonitor juiz) {
        this.num = num;
        this.monitor = juiz;
    }
    
    public void configura(int min, int max, int tempo, int tamPista) {
        this.menorDistancia = min;
        this.maiorDistancia = max;
        this.tempoEspera = tempo;
        this.distanciaPercurso = tamPista;
    }
    
    @Override
    public void run() {
        System.out.printf("Cavalo %d pronto e aguardando a largada.\n",num);
        while( !monitor.largou() ) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Logger.getLogger(CavaloThread.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        // percurso
        System.out.printf("Cavalo %d largou.\n",num);
        java.util.Random rand = new java.util.Random();
        int percorreu = 0;
        while( percorreu < distanciaPercurso ) {
            int andou = rand.nextInt(maiorDistancia-menorDistancia)+menorDistancia;
            try {
                Thread.sleep(tempoEspera);
            } catch (InterruptedException ex) {
                //
            }
            percorreu += andou;
            System.out.printf("O cavalo %d percorreu %dm\n",num,percorreu);
        }
        // avisa o juiz
        monitor.encerrou(num);
    }
    
}
